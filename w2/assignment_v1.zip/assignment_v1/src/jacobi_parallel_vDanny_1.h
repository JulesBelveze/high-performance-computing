void jacobi_paralleld_one(int n, int num_iterations, double **f, double **u, double threshold);
