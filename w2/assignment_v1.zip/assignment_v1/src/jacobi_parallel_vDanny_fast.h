void jacobi_parallel_d_fast(int n, int num_iterations, double **f, double **u, double threshold);
