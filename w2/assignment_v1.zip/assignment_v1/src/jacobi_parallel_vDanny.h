void jacobi_parallel_d(int n, int num_iterations, double **f, double **u, double threshold);
