void gauss(int N, int num_iterations, double **f, double **u_new, double threshold);
