void jacobi_parallel_2(int N, int num_iterations, double **f, double **u, double threshold);
