void jacobi_parallel_naive(int N, int num_iterations, double **f, double **u, double threshold);
