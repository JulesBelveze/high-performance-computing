void jacobi(int N, int num_iterations, double **f, double **u, double threshold);
