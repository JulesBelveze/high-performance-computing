void jacobi_parallel_1(int N, int num_iterations, double **f, double **u, double threshold);
