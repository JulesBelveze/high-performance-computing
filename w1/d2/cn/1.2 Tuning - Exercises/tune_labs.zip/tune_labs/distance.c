#include "data.h"

#ifdef ARRAY_OF_STRUCTS
double 
distance(particle_t *p, int n) {
    
    double dist = -99.0;
    /* fill in your code here
     *
     */
    return dist;
}
#else
double 
distance(particle_t p, int n) {

    double dist = -99.0;
    /* fill in your code here
     *
     */
    return dist;
}
#endif
