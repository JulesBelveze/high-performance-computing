#ifndef __XTIME_H
#define __XTIME_H

void init_timer(void);
void timer(int *nthreads);
double xtime(void);

#endif
